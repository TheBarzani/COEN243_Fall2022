#include <iostream>
using namespace std;

int main(){
	int i = 0;
	while (true){
		system("cls");
		cout << i << endl << endl;
		i++;
		for (int k=0; k<10e8; k++);

	}
}